@echo off
title BozduxanDLC
mode con cols=80 lines=28

rem === CONFIGURATION ===
rem GitHub release URL for the FULL runtime archive (BozduxanDLC-full.zip)
set RUNTIME_URL=
set TEMP_ZIP=%TEMP%\BozduxanDLC-full.zip

set RAM_FILE=%~dp0ram.txt
if exist "%RAM_FILE%" (
    set /p RAM=<"%RAM_FILE%"
) else (
    set RAM=2048
)

:menu
cls
echo.
echo  ____              _                 _   _
echo ^| __ ^)  ___ ______^| ^|_   ___  ____ _^| \ ^| ^|
echo ^|  _ \ / _ \_  / _\` ^| ^| ^| \ \/ / _\` ^|  \^|
echo ^| ^|_) ^| ^(_) / / ^(_^| ^| ^|_^| ^|^>  ^< ^(_^| ^| ^|\  ^|
echo ^|____/ \___/___\__,_^|\__,_/_/\_\__,_^|_^| \_^|
echo.
echo                   [1] - Download ^& Play
echo                   [2] - OZU
echo.
set /p choice="Select: "

if "%choice%"=="1" goto check_files
if "%choice%"=="2" goto ram_menu
goto menu

:check_files
if not exist "%~dp0BozduxanDLC.jar" goto download
if not exist "%~dp0libraries\*.jar" goto download
goto launch

:download
cls
echo.
echo  ____              _                 _   _
echo ^| __ ^)  ___ ______^| ^|_   ___  ____ _^| \ ^| ^|
echo ^|  _ \ / _ \_  / _\` ^| ^| ^| \ \/ / _\` ^|  \^|
echo ^| ^|_) ^| ^(_) / / ^(_^| ^| ^|_^| ^|^>  ^< ^(_^| ^| ^|\  ^|
echo ^|____/ \___/___\__,_^|\__,_/_/\_\__,_^|_^| \_^|
echo.
echo          Downloading BozduxanDLC...

if "%RUNTIME_URL%"=="" (
    echo [!] Download URL not configured!
    echo     Open Bozduxan.bat and set RUNTIME_URL
    echo     Example: https://github.com/USER/REPO/releases/latest/download/BozduxanDLC-full.zip
    pause
    goto menu
)

echo Downloading runtime...
curl -L -o "%TEMP_ZIP%" "%RUNTIME_URL%" --progress-bar
if %errorlevel% neq 0 (
    echo [!] Download failed!
    pause
    goto menu
)

echo Extracting...
powershell -Command "Expand-Archive -Path '%TEMP_ZIP%' -DestinationPath '%~dp0' -Force"
if %errorlevel% neq 0 (
    echo [!] Extraction failed!
    pause
    goto menu
)

del "%TEMP_ZIP%" 2>nul
echo [+] Download complete!
timeout /t 1 >nul
goto launch

:ram_menu
cls
echo.
echo  ____              _                 _   _
echo ^| __ ^)  ___ ______^| ^|_   ___  ____ _^| \ ^| ^|
echo ^|  _ \ / _ \_  / _\` ^| ^| ^| \ \/ / _\` ^|  \^|
echo ^| ^|_) ^| ^(_) / / ^(_^| ^| ^|_^| ^|^>  ^< ^(_^| ^| ^|\  ^|
echo ^|____/ \___/___\__,_^|\__,_/_/\_\__,_^|_^| \_^|
echo.
echo                Select RAM (MB):
echo.
echo                    [1] 1024 MB  (1 GB)
echo                    [2] 2048 MB  (2 GB)
echo                    [3] 3072 MB  (3 GB)
echo                    [4] 4096 MB  (4 GB)
echo                    [5] 6144 MB  (6 GB)
echo                    [6] 8192 MB  (8 GB)
echo                    [7] Custom
echo                    [0] Back
echo.
set /p ram_choice="Select: "

if "%ram_choice%"=="1" set RAM=1024
if "%ram_choice%"=="2" set RAM=2048
if "%ram_choice%"=="3" set RAM=3072
if "%ram_choice%"=="4" set RAM=4096
if "%ram_choice%"=="5" set RAM=6144
if "%ram_choice%"=="6" set RAM=8192
if "%ram_choice%"=="7" goto custom_ram
if "%ram_choice%"=="0" goto menu

echo %RAM%>"%RAM_FILE%"
echo [+] RAM saved: %RAM% MB
timeout /t 1 >nul
goto menu

:custom_ram
set /p RAM="Enter RAM in MB (e.g. 2048): "
echo %RAM%>"%RAM_FILE%"
echo [+] RAM saved: %RAM% MB
timeout /t 1 >nul
goto menu

:launch
set TL_ASSETS=%APPDATA%\.tlauncher\legacy\Minecraft\game\assets
if not exist "%~dp0game\assets\indexes\1.16.json" (
    echo [*] Setting up game assets...
    if not exist "%~dp0game\assets" mkdir "%~dp0game\assets"
    if exist "%TL_ASSETS%\indexes\1.16.json" (
        echo [*] Copying Minecraft 1.16 assets...
        copy "%TL_ASSETS%\indexes\1.16.json" "%~dp0game\assets\indexes\1.16.json" >nul
        xcopy /E /I /Y "%TL_ASSETS%\objects" "%~dp0game\assets\objects" >nul
        echo [+] Assets ready!
    ) else (
        echo [!] Minecraft 1.16 assets not found!
        pause
        exit /b 1
    )
)

echo [*] Starting Client with %RAM% MB RAM...
java -Xmx%RAM%m -Xms%RAM%m -cp "BozduxanDLC.jar;libraries\*" -Djava.library.path="libraries\natives" Start
if errorlevel 1 (
    echo [!] Game crashed with error code: %errorlevel%
    pause
)
goto menu
